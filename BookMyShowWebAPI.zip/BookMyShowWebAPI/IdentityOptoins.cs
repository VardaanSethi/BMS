﻿namespace BookMyShowWebAPI
{
    internal class IdentityOptoins
    {
        public object Password { get; internal set; }
    }
}