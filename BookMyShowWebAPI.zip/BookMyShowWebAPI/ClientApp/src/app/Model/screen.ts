export class Screen {
    screenId:number;
    theaterId: number;
    movieId:number;
    noOfSeats:number;
}