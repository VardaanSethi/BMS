export class Show {
    showId:number;
    theaterId: number;
    showTiming: Date;
}