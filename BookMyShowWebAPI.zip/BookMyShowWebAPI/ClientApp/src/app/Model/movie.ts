export class Movie {
    movieId: number;
    movieTitle: string;
    movieDescription: string;
    movieLanguage: string;
}