export class Theater{
    theaterId:number;
    theaterName:string;
    theaterAddress:string;
    noOfScreens:number;
}